function toggle_menu(){
    let x = document.getElementById('menu_container'); 

    if (x.style.display == "none"){
        x.style.display = "block"; 
    }else{
        x.style.display = "none"
    }
}

function toggle_wallpaper(){
    let wallpaper_1 = document.getElementById('wallpaper_1'); 
    let wallpaper_2 = document.getElementById('wallpaper_2'); 
    let wallpaper_3 = document.getElementById('wallpaper_3'); 
    
    if (wallpaper_1.style.display == "flex"){
        wallpaper_2.style.display = "flex"; 
        wallpaper_3.style.display = "none"; 
        wallpaper_1.style.display = "none"; 
    }else if (wallpaper_2.style.display == "flex"){
        wallpaper_1.style.display = "none"; 
        wallpaper_2.style.display = "none"; 
        wallpaper_3.style.display = "flex"; 
    }else{
        wallpaper_1.style.display = "flex"; 
        wallpaper_2.style.display = "none"; 
        wallpaper_3.style.display = "none"; 
    }

}

setInterval(() => {toggle_wallpaper()}, 4000);